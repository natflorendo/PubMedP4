SELECT pmid 
FROM text_chunks
GROUP BY pmid;
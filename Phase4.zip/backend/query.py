from fastapi import APIRouter, Depends

from .auth import get_current_user
from .models import QueryRequest, QueryResponse
from .query_service import QueryService


router = APIRouter(tags=["query"])
query_service = QueryService()


@router.post("/query", response_model=QueryResponse)
def run_query(payload: QueryRequest, current_user=Depends(get_current_user)):
    result = query_service.run_query(
        payload.query,
        top_k=payload.k,
        include_answer=payload.include_answer,
        answer_model=payload.answer_model,
        user_id=current_user["user_id"],
    )
    return result

from __future__ import annotations

import os
from pathlib import Path

from pipeline.config.config import PipelineConfig, load_config
from pipeline.core.retriever import search_index


class QueryService:
    """Runs similarity search and optional LLM answers for the API layer."""

    def __init__(self, config_path: str | None = None) -> None:
        default_config = (
            Path(__file__).resolve().parents[1] / "pipeline" / "config" / "config.toml"
        )
        self._config_path = config_path or os.getenv("PUBMEDFLO_PIPELINE_CONFIG", str(default_config))
        self._config: PipelineConfig | None = None

    # @property turns the method into a read-only attribute.
    @property
    def config(self) -> PipelineConfig:
        if self._config is None:
            # Use load_config function to load input sections from config.toml.
            self._config = load_config(self._config_path)
        return self._config

    def run_query(
        self,
        query_text: str,
        top_k: int = 5,
        include_answer: bool = True,
        answer_model: str | None = None,
        user_id: int | None = None,
    ) -> dict:
        config = self.config
        llm_model = answer_model or config.generation.llm_model
        results, answer, query_id = search_index(
            config,
            query_text,
            top_k,
            answer_model=llm_model if include_answer else None,
            user_id=user_id,
        )

        citations = []
        seen_pmids: set[int] = set()
        for result in results:
            pmid = result["pmid"]
            if pmid in seen_pmids:
                continue
            seen_pmids.add(pmid)
            citations.append(
                {
                    "pmid": pmid,
                    "title": result["title"],
                    "doc_id": result["doc_id"],
                }
            )

        retrieved_chunks = [
            {
                "chunk_id": item["chunk_id"],
                "pmid": item["pmid"],
                "doc_id": item["doc_id"],
                "title": item["title"],
                "score": item["score"],
                "chunk_text": item["chunk_text"],
            }
            for item in results
        ]

        return {
            "query_id": query_id,
            "answer": answer,
            "citations": citations,
            "retrieved_chunks": retrieved_chunks,
        }

from fastapi import APIRouter, Depends, HTTPException, status
from psycopg import errors

from .auth import get_password_hash, require_roles
from .models import UserOut, UserUpdate
from .repository import UserRepository, get_db

router = APIRouter(
    prefix="/admin",
    tags=["admin"],
    dependencies=[Depends(require_roles(["admin"]))],
)


@router.get("/users", response_model=list[UserOut])
def list_users(conn=Depends(get_db)):
    repo = UserRepository(conn)
    return [UserOut(**row) for row in repo.list_users()]


@router.put("/users/{user_id}", response_model=UserOut)
def update_user(user_id: int, payload: UserUpdate, conn=Depends(get_db)):
    repo = UserRepository(conn)
    hashed = get_password_hash(payload.password) if payload.password else None

    try:
        updated = repo.update_user(
            user_id,
            name=payload.name,
            email=payload.email,
            password_hash=hashed,
            roles=payload.roles,
        )
    except errors.UniqueViolation:
        conn.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Email already in use"
        )

    if not updated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )
    return UserOut(**updated)


@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int, conn=Depends(get_db)):
    repo = UserRepository(conn)
    success = repo.delete_user(user_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )
